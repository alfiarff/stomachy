import 'package:flutter/material.dart';
import 'package:bootstrap_icons/bootstrap_icons.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'home_screen.dart';
import 'screening_screen.dart';
import 'doctor_screen.dart';
import 'edukasi_screen.dart';
import 'profile_screen.dart';
import '../widgets/bottom_navigation.dart';
import 'change_password_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // ===============================================================
  // SELECTED BOTTOM NAVIGATION
  // ===============================================================

  int _selectedIndex = 4;

  // ===============================================================
  // WARNA
  // ===============================================================

  final Color backgroundColor = const Color(0xFFFFF5EF);

  // Brown utama STOMACHY
  final Color brown = const Color(0xFFB05039);

  // ===============================================================
  // STATUS TOGGLE
  //
  // notificationApp = master toggle.
  // Kalau master OFF, 4 sub-notifikasi di bawahnya
  // menjadi redup dan tidak bisa diubah.
  // ===============================================================

  bool notifArtikel = true;
  bool notifEdukasi = true;
  bool notifOlahraga = true;
  bool notifMakanan = true;
  bool notifBalasanDokter = false;

  bool _isLoading = true;

  // ===============================================================
  // INIT
  // ===============================================================

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  // ===============================================================
  // LOAD PENGATURAN DARI FIRESTORE
  // ===============================================================

  Future<void> _loadSettings() async {
    try {
      final user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (doc.exists) {
          final data = doc.data();

          if (data != null) {
            final settings = data['settings'];

            if (settings is Map) {
              setState(() {
                notifArtikel =
                    settings['notifArtikel'] as bool? ?? notifArtikel;

                notifEdukasi =
                    settings['notifEdukasi'] as bool? ?? notifEdukasi;

                notifMakanan =
                    settings['notifMakanan'] as bool? ?? notifMakanan;

                notifOlahraga =
                    settings['notifOlahraga'] as bool? ?? notifOlahraga;

                notifBalasanDokter =
                    settings['notifBalasanDokter'] as bool? ??
                    notifBalasanDokter;
              });
            }
          }
        }
      }
    } catch (e) {
      debugPrint('SETTINGS LOAD ERROR: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // ===============================================================
  // SIMPAN PENGATURAN KE FIRESTORE
  // ===============================================================

  Future<void> _saveSettings() async {
    try {
      final user = FirebaseAuth.instance.currentUser;

      if (user == null) {
        return;
      }

      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
      'settings': {
        'notifArtikel': notifArtikel,
        'notifEdukasi': notifEdukasi,
        'notifMakanan': notifMakanan,
        'notifOlahraga': notifOlahraga,
        'notifBalasanDokter': notifBalasanDokter,
      },
        'settingsUpdatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('SETTINGS SAVE ERROR: $e');
    }
  }

  // ===============================================================
  // NAVIGATION
  // ===============================================================

  void _onNavigationTap(int index) {
    if (index == _selectedIndex) {
      return;
    }

    // BERANDA
    if (index == 0) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
      return;
    }

    // SKRINING
    if (index == 1) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const ScreeningScreen()),
      );
      return;
    }

    // DOKTER
    if (index == 2) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const DoctorScreen()),
      );
      return;
    }

    // EDUKASI
    if (index == 3) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const EdukasiScreen()),
      );
      return;
    }

    // PROFIL
    if (index == 4) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const ProfileScreen()),
      );
      return;
    }
  }

  // ===============================================================
  // BUILD
  // ===============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,

      body: SafeArea(
        child: _isLoading
            ? Center(child: CircularProgressIndicator(color: brown))
            : SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(22, 12, 22, 105),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // =============================================
                    // HEADER
                    // =============================================

                    _buildHeader(),

                    const SizedBox(height: 27),

                    // =============================================
                    // BAGIAN AKUN
                    // =============================================
                    _buildSectionTitle('Akun'),

                    const SizedBox(height: 10),

                    _buildAccountCard(),

                    const SizedBox(height: 23),

                    // =============================================
                    // BAGIAN NOTIFIKASI
                    // =============================================
                    _buildSectionTitle('Notifikasi'),

                    const SizedBox(height: 10),

                    // BALASAN DOKTER
                    _buildSimpleNotificationCard(
                      icon: BootstrapIcons.chat_dots,
                      title: 'Balasan Dokter',
                      value: notifBalasanDokter,
                      onChanged: (value) {
                        setState(() {
                          notifBalasanDokter = value;
                        });
                        _saveSettings();
                      },
                    ),

                    const SizedBox(height: 20),

                    // EDUKASI
                    _buildSimpleNotificationCard(
                      icon: BootstrapIcons.book,
                      title: 'Edukasi',
                      value: notifEdukasi,
                      onChanged: (value) {
                        setState(() {
                          notifEdukasi = value;
                        });
                        _saveSettings();
                      },
                    ),

                    const SizedBox(height: 10),

                    // ARTIKEL MINGGUAN
                    _buildSimpleNotificationCard(
                      icon: BootstrapIcons.newspaper,
                      title: 'Artikel Mingguan',
                      value: notifArtikel,
                      onChanged: (value) {
                        setState(() {
                          notifArtikel = value;
                        });
                        _saveSettings();
                      },
                    ),

                    const SizedBox(height: 10),

                    // REKOMENDASI MAKANAN
                    _buildSimpleNotificationCard(
                      icon: BootstrapIcons.egg_fried,
                      title: 'Rekomendasi Makanan',
                      value: notifMakanan,
                      onChanged: (value) {
                        setState(() {
                          notifMakanan = value;
                        });
                        _saveSettings();
                      },
                    ),

                    const SizedBox(height: 10),

                    // REKOMENDASI OLAHRAGA
                    _buildSimpleNotificationCard(
                      icon: BootstrapIcons.bicycle,
                      title: 'Rekomendasi Olahraga',
                      value: notifOlahraga,
                      onChanged: (value) {
                        setState(() {
                          notifOlahraga = value;
                        });
                        _saveSettings();
                      },
                    ),

                    const SizedBox(height: 10),

                  ],
                ),
              ),
      ),

      // ===========================================================
      // BOTTOM NAVIGATION
      // ===========================================================
      bottomNavigationBar: AppBottomNavigation(
        selectedIndex: _selectedIndex,
        onItemSelected: _onNavigationTap,
      ),
    );
  }

  // ===============================================================
  // HEADER
  // ===============================================================

  Widget _buildHeader() {
    return SizedBox(
      height: 42,
      child: Row(
        children: [
          // =======================================================
          // TOMBOL KEMBALI
          // =======================================================

          GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: const SizedBox(
              width: 45,
              height: 42,
              child: Align(
                alignment: Alignment.centerLeft,
                child: Icon(
                  Icons.arrow_back_rounded,
                  size: 29,
                  color: Colors.black,
                ),
              ),
            ),
          ),

          // =======================================================
          // JUDUL
          // =======================================================
          const Expanded(
            child: Center(
              child: Text(
                'Pengaturan',
                style: TextStyle(
                  fontFamily: 'Fredoka',
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                ),
              ),
            ),
          ),

          // =======================================================
          // PENYEIMBANG
          // =======================================================
          const SizedBox(width: 45),
        ],
      ),
    );
  }

  // ===============================================================
  // SECTION TITLE
  // ===============================================================

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontFamily: 'Nunito',
        fontSize: 12,
        fontWeight: FontWeight.w800,
        color: Colors.black,
      ),
    );
  }

  // ===============================================================
  // ACCOUNT CARD
  // ===============================================================

  Widget _buildAccountCard() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ChangePasswordScreen()),
        );
      },
      child: Container(
        width: double.infinity,
        height: 58,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(17),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            // =====================================================
            // ICON
            // =====================================================

            Container(
              width: 40,
              height: 40,
              decoration: const BoxDecoration(
                color: Color(0xFFFFE8D8),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Icon(BootstrapIcons.lock, size: 19, color: brown),
              ),
            ),

            const SizedBox(width: 10),

            // =====================================================
            // TEXT
            // =====================================================
            const Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Ubah Kata Sandi',
                    style: TextStyle(
                      fontFamily: 'Nunito',
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: Colors.black,
                    ),
                  ),

                  SizedBox(height: 1),
                ],
              ),
            ),

            // =====================================================
            // CHEVRON
            // =====================================================
            Icon(Icons.chevron_right_rounded, size: 25, color: brown),
          ],
        ),
      ),
    );
  }

  // ===============================================================
  // KARTU NOTIFIKASI SEDERHANA
  // ===============================================================

  Widget _buildSimpleNotificationCard({
    required IconData icon,
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      width: double.infinity,
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: const BoxDecoration(
              color: Color(0xFFFFE8D8),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Icon(icon, size: 19, color: brown),
            ),
          ),

          const SizedBox(width: 10),

          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontFamily: 'Nunito',
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: Colors.black,
              ),
            ),
          ),

          _buildCustomSwitch(
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  // ===============================================================
  // CUSTOM SWITCH
  //
  // ON  -> track brown, thumb putih
  // OFF -> track abu terang, thumb putih
  // ===============================================================

  Widget _buildCustomSwitch({
    required bool value,
    required ValueChanged<bool>? onChanged,
  }) {
    final bool enabled = onChanged != null;

    return GestureDetector(
      onTap: enabled
          ? () {
              onChanged!(!value);
            }
          : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
        width: 44,
        height: 25,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: value ? brown : const Color(0xFFE5DDD8),
          borderRadius: BorderRadius.circular(20),
        ),
        child: AnimatedAlign(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
          alignment: value ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            width: 19,
            height: 19,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}