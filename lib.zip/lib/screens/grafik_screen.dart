import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'home_screen.dart';
import 'screening_screen.dart';
import 'doctor_screen.dart';
import 'edukasi_screen.dart';
import 'profile_screen.dart';
import '../widgets/bottom_navigation.dart';
import '../widgets/stomachy_card.dart';

class GrafikScreen extends StatefulWidget {
  const GrafikScreen({super.key});

  @override
  State<GrafikScreen> createState() => _GrafikScreenState();
}

// =====================================================================
// MODEL DATA RIWAYAT SKRINING
// =====================================================================

class ScreeningHistory {
  final DateTime date;
  final bool atRisk;
  final List<String> complaints;

  const ScreeningHistory({
    required this.date,
    required this.atRisk,
    required this.complaints,
  });
}

// =====================================================================
// SCREEN
// =====================================================================

class _GrafikScreenState extends State<GrafikScreen> {
  int _selectedIndex = 4;

  final Color backgroundColor = const Color(0xFFFFF5EF);

  // Warna brown utama STOMACHY
  final Color brown = const Color(0xFFB05039);

  // ===================================================================
  // NAVIGATION
  // ===================================================================

  void _onNavigationTap(int index) {
    if (index == _selectedIndex) {
      return;
    }

    if (index == 0) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
      return;
    }

    if (index == 1) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const ScreeningScreen()),
      );
      return;
    }

    if (index == 2) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const DoctorScreen()),
      );
      return;
    }

    if (index == 3) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const EdukasiScreen()),
      );
      return;
    }

    if (index == 4) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const ProfileScreen()),
      );
      return;
    }
  }

  // ===================================================================
  // BUILD
  // ===================================================================

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      backgroundColor: backgroundColor,

      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(22, 12, 22, 105),
          child: Column(
            children: [
              _buildHeader(),

              const SizedBox(height: 18),

              if (user == null)
                _buildEmptyState('Silakan login terlebih dahulu.')
              else
                _buildHistoryStream(user.uid),
            ],
          ),
        ),
      ),

      bottomNavigationBar: AppBottomNavigation(
        selectedIndex: _selectedIndex,
        onItemSelected: _onNavigationTap,
      ),
    );
  }

  // ===================================================================
  // STREAM RIWAYAT SKRINING DARI FIRESTORE
  // ===================================================================

  Widget _buildHistoryStream(String uid) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .collection('screening_history')
          .orderBy('createdAt', descending: false)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Padding(
            padding: EdgeInsets.only(top: 60),
            child: CircularProgressIndicator(color: Color(0xFFB05039)),
          );
        }

        if (snapshot.hasError) {
          return _buildEmptyState(
            'Gagal memuat riwayat skrining. Coba lagi nanti.',
          );
        }

        final List<ScreeningHistory> history = _convertDocuments(
          snapshot.data?.docs ?? [],
        );

        if (history.isEmpty) {
          return _buildEmptyState(
            'Belum ada riwayat skrining. Lakukan skrining untuk melihat grafiknya di sini.',
          );
        }

        return Column(
          children: [
            _buildDevelopmentCard(history),

            const SizedBox(height: 12),

            _buildSummaryCard(history),

            const SizedBox(height: 12),

            _buildComplaintCard(history),

            const SizedBox(height: 12),

            _buildInformationCard(),

            const SizedBox(height: 20),
          ],
        );
      },
    );
  }

  // ===================================================================
  // KONVERSI DOKUMEN FIRESTORE -> LIST MODEL
  // ===================================================================

  List<ScreeningHistory> _convertDocuments(
    List<QueryDocumentSnapshot<Map<String, dynamic>>> docs,
  ) {
    final List<ScreeningHistory> result = [];

    for (final doc in docs) {
      final data = doc.data();

      final DateTime date = _parseDate(data['createdAt'], data['date']);

      final bool atRisk = data['isRisk'] == true;

      final List<String> complaints = _parseComplaints(data['complaint']);

      result.add(
        ScreeningHistory(date: date, atRisk: atRisk, complaints: complaints),
      );
    }

    return result;
  }

  // ===================================================================
  // PARSE TANGGAL
  // ===================================================================

  DateTime _parseDate(dynamic createdAt, dynamic oldDate) {
    if (createdAt is Timestamp) {
      return createdAt.toDate();
    }

    if (oldDate is String && oldDate.isNotEmpty) {
      final DateTime? parsed = DateTime.tryParse(oldDate);

      if (parsed != null) {
        return parsed;
      }
    }

    return DateTime.now();
  }

  // ===================================================================
  // PARSE KELUHAN
  // ===================================================================

  List<String> _parseComplaints(dynamic value) {
    if (value == null) {
      return [];
    }

    final String text = value.toString().trim();

    if (text.isEmpty) {
      return [];
    }

    if (text.toLowerCase() == 'tidak ada keluhan') {
      return [];
    }

    return text
        .split(',')
        .map((item) => item.trim())
        .where((item) => item.isNotEmpty)
        .toList();
  }

  // ===================================================================
  // EMPTY STATE
  // ===================================================================

  Widget _buildEmptyState(String message) {
    return StomachyCard(
      color: const Color(0xFFFFFCF9),
      radius: 16,
      padding: const EdgeInsets.symmetric(vertical: 35, horizontal: 20),
      child: Column(
        children: [
          Icon(Icons.bar_chart_rounded, size: 45, color: brown),

          const SizedBox(height: 12),

          Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontFamily: 'Nunito',
              fontSize: 11,
              height: 1.4,
              fontWeight: FontWeight.w400,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  // ===================================================================
  // HEADER
  // ===================================================================

  Widget _buildHeader() {
    return SizedBox(
      height: 42,
      child: Row(
        children: [
          GestureDetector(
            onTap: () {
              Navigator.pop(context);
            },
            child: const SizedBox(
              width: 45,
              height: 42,
              child: Align(
                alignment: Alignment.centerLeft,
                child: Icon(
                  Icons.arrow_back_rounded,
                  size: 29,
                  color: Colors.black,
                ),
              ),
            ),
          ),

          const Expanded(
            child: Center(
              child: Text(
                'Grafik',
                style: TextStyle(
                  fontFamily: 'Fredoka',
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: Colors.black,
                ),
              ),
            ),
          ),

          const SizedBox(width: 45),
        ],
      ),
    );
  }

  // ===================================================================
  // CARD GRAFIK
  // ===================================================================

  Widget _buildDevelopmentCard(List<ScreeningHistory> history) {
    return StomachyCard(
      color: const Color(0xFFFFFCF9),
      radius: 16,
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFE5D8),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(Icons.bar_chart_rounded, size: 18, color: brown),
              ),

              const SizedBox(width: 10),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'Perkembangan Skrining GERD',
                      style: TextStyle(
                        fontFamily: 'Nunito',
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: Colors.black,
                      ),
                    ),

                    SizedBox(height: 2),

                    Text(
                      'Lihat perubahan hasil skrining kamu dari waktu ke waktu.',
                      style: TextStyle(
                        fontFamily: 'Nunito',
                        fontSize: 11,
                        fontWeight: FontWeight.w400,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 10),

          Container(
            width: double.infinity,
            height: 145,
            padding: const EdgeInsets.fromLTRB(2, 4, 2, 0),
            decoration: BoxDecoration(
              color: const Color(0xFFFFEBDD),
              borderRadius: BorderRadius.circular(18),
            ),
            child: CustomPaint(
              painter: GERDChartPainter(history: history),
              child: const SizedBox.expand(),
            ),
          ),

          const SizedBox(height: 8),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildLegendItem(
                color: const Color(0xFFE96B68),
                text: 'Berisiko GERD',
              ),

              const SizedBox(width: 28),

              _buildLegendItem(
                color: const Color(0xFF61C58A),
                text: 'Tidak Berisiko GERD',
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ===================================================================
  // LEGEND
  // ===================================================================

  Widget _buildLegendItem({required Color color, required String text}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),

        const SizedBox(width: 5),

        Text(
          text,
          style: const TextStyle(
            fontFamily: 'Nunito',
            fontSize: 11,
            fontWeight: FontWeight.w400,
            color: Colors.black,
          ),
        ),
      ],
    );
  }

  // ===================================================================
  // SUMMARY CARD
  // ===================================================================

  Widget _buildSummaryCard(List<ScreeningHistory> history) {
    final int total = history.length;

    final int riskCount = history.where((item) => item.atRisk).length;

    final int safeCount = history.where((item) => !item.atRisk).length;

    return StomachyCard(
      color: const Color(0xFFFFFCF9),
      radius: 16,
      padding: const EdgeInsets.fromLTRB(12, 11, 12, 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFE5D8),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(Icons.article_outlined, size: 18, color: brown),
              ),

              const SizedBox(width: 10),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Ringkasan Hasil Skrining',
                    style: TextStyle(
                      fontFamily: 'Nunito',
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: Colors.black,
                    ),
                  ),

                  SizedBox(height: 1),

                  Text(
                    'Ringkasan riwayat skrining anda',
                    style: TextStyle(
                      fontFamily: 'Nunito',
                      fontSize: 11,
                      fontWeight: FontWeight.w400,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 10),

          Container(
            width: double.infinity,
            height: 103,
            decoration: BoxDecoration(
              color: const Color(0xFFFFE6D3),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              children: [
                Expanded(
                  child: _buildSummaryItem(
                    title: 'Total Skrining',
                    value: '$total',
                    suffix: 'Kali',
                    valueColor: brown,
                  ),
                ),

                _buildVerticalDivider(),

                Expanded(
                  child: _buildSummaryItem(
                    title: 'Berisiko GERD',
                    value: '$riskCount',
                    suffix: 'Kali',
                    valueColor: const Color(0xFFE96B68),
                  ),
                ),

                _buildVerticalDivider(),

                Expanded(
                  child: _buildSummaryItem(
                    title: 'Tidak berisiko GERD',
                    value: '$safeCount',
                    suffix: 'Kali',
                    valueColor: const Color(0xFF16805C),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ===================================================================
  // SUMMARY ITEM
  // ===================================================================

  Widget _buildSummaryItem({
    required String title,
    required String value,
    required String suffix,
    required Color valueColor,
  }) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          title,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontFamily: 'Nunito',
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),

        const SizedBox(height: 7),

        Text(
          value,
          style: TextStyle(
            fontFamily: 'Nunito',
            fontSize: 22,
            fontWeight: FontWeight.w800,
            color: valueColor,
          ),
        ),

        Text(
          suffix,
          style: TextStyle(
            fontFamily: 'Nunito',
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: valueColor,
          ),
        ),
      ],
    );
  }

  // ===================================================================
  // VERTICAL DIVIDER
  // ===================================================================

  Widget _buildVerticalDivider() {
    return Container(width: 1, height: 66, color: const Color(0xFFD6B5A2));
  }

  // ===================================================================
  // COMPLAINT CARD
  // ===================================================================

  Widget _buildComplaintCard(List<ScreeningHistory> history) {
    final Map<String, int> complaintCount = {};

    for (final historyItem in history) {
      for (final complaint in historyItem.complaints) {
        complaintCount[complaint] = (complaintCount[complaint] ?? 0) + 1;
      }
    }

    final int totalHistory = history.length;

    final List<MapEntry<String, int>> sortedComplaints =
        complaintCount.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));

    return StomachyCard(
      color: const Color(0xFFFFFCF9),
      radius: 16,
      padding: const EdgeInsets.fromLTRB(12, 11, 12, 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFE5D8),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Icon(Icons.assignment_outlined, size: 18, color: brown),
              ),

              const SizedBox(width: 10),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Keluhan yang sering dipilih',
                    style: TextStyle(
                      fontFamily: 'Nunito',
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: Colors.black,
                    ),
                  ),

                  SizedBox(height: 1),

                  Text(
                    'Berdasarkan seluruh riwayat skrining anda',
                    style: TextStyle(
                      fontFamily: 'Nunito',
                      fontSize: 11,
                      fontWeight: FontWeight.w400,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 13),

          if (sortedComplaints.isEmpty)
            const Padding(
              padding: EdgeInsets.all(15),
              child: Center(
                child: Text(
                  'Belum ada data keluhan.',
                  style: TextStyle(
                    fontFamily: 'Nunito',
                    fontSize: 11,
                    fontWeight: FontWeight.w400,
                    color: Colors.black,
                  ),
                ),
              ),
            )
          else
            ...sortedComplaints.take(5).map((entry) {
              final double percentage = totalHistory == 0
                  ? 0
                  : entry.value / totalHistory;

              final int percentageValue = (percentage * 100).round();

              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _buildComplaintRow(
                  label: entry.key,
                  percentage: percentage,
                  percentageText: '$percentageValue%',
                ),
              );
            }),
        ],
      ),
    );
  }

  // ===================================================================
  // COMPLAINT ROW
  // ===================================================================

  Widget _buildComplaintRow({
    required String label,
    required double percentage,
    required String percentageText,
  }) {
    return Row(
      children: [
        SizedBox(
          width: 105,
          child: Text(
            label,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontFamily: 'Nunito',
              fontSize: 11,
              fontWeight: FontWeight.w400,
              height: 1.2,
              color: Colors.black,
            ),
          ),
        ),

        const SizedBox(width: 6),

        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: percentage,
              minHeight: 9,
              backgroundColor: const Color(0xFFF1E4DE),
              valueColor: const AlwaysStoppedAnimation<Color>(
                Color(0xFFB05039),
              ),
            ),
          ),
        ),

        const SizedBox(width: 8),

        SizedBox(
          width: 28,
          child: Text(
            percentageText,
            textAlign: TextAlign.right,
            style: const TextStyle(
              fontFamily: 'Nunito',
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Colors.black,
            ),
          ),
        ),
      ],
    );
  }

  // ===================================================================
  // INFORMATION CARD
  // ===================================================================

  Widget _buildInformationCard() {
    return StomachyCard(
      color: const Color(0xFFFFFCF9),
      radius: 16,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 25,
            height: 25,
            decoration: const BoxDecoration(
              color: Color(0xFFFFEEE5),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.priority_high_rounded, size: 17, color: brown),
          ),

          const SizedBox(width: 9),

          const Expanded(
            child: Text(
              'Grafik membantu melihat perubahan hasil skrining dari waktu ke waktu.',
              style: TextStyle(
                fontFamily: 'Nunito',
                fontSize: 11,
                fontWeight: FontWeight.w400,
                height: 1.35,
                color: Colors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =====================================================================
// CUSTOM PAINTER GRAFIK GERD
// =====================================================================

class GERDChartPainter extends CustomPainter {
  final List<ScreeningHistory> history;

  GERDChartPainter({required this.history});

  @override
  void paint(Canvas canvas, Size size) {
    if (history.isEmpty) {
      _drawEmptyState(canvas, size);
      return;
    }

    // ================================================================
    // AREA GRAFIK
    // ================================================================

    const double leftPadding = 58;
    const double rightPadding = 10;
    const double topPadding = 17;
    const double bottomPadding = 32;

    final double chartWidth = size.width - leftPadding - rightPadding;

    final double chartHeight = size.height - topPadding - bottomPadding;

    final double chartLeft = leftPadding;
    final double chartRight = size.width - rightPadding;

    final double chartTop = topPadding;
    final double chartBottom = topPadding + chartHeight;

    // ================================================================
    // PAINT
    // ================================================================

    final Paint gridPaint = Paint()
      ..color = const Color(0xFFE8CFC3)
      ..strokeWidth = 0.8;

    final Paint riskLinePaint = Paint()
      ..color = const Color(0xFFE96B68)
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;

    final Paint safeLinePaint = Paint()
      ..color = const Color(0xFF61C58A)
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;

    // ================================================================
    // BACKGROUND GRID
    // ================================================================

    canvas.drawLine(
      Offset(chartLeft, chartTop),
      Offset(chartRight, chartTop),
      gridPaint,
    );

    canvas.drawLine(
      Offset(chartLeft, chartBottom),
      Offset(chartRight, chartBottom),
      gridPaint,
    );

    final double middleY = chartTop + chartHeight / 2;

    canvas.drawLine(
      Offset(chartLeft, middleY),
      Offset(chartRight, middleY),
      gridPaint,
    );

    final int count = history.length;

    if (count > 1) {
      for (int i = 0; i < count; i++) {
        final double x = chartLeft + (chartWidth * i / (count - 1));

        canvas.drawLine(Offset(x, chartTop), Offset(x, chartBottom), gridPaint);
      }
    } else {
      canvas.drawLine(
        Offset(chartLeft, chartTop),
        Offset(chartLeft, chartBottom),
        gridPaint,
      );
    }

    // ================================================================
    // POSISI TITIK
    // ================================================================

    final List<Offset> points = [];

    for (int i = 0; i < history.length; i++) {
      final ScreeningHistory item = history[i];

      double x;

      if (history.length == 1) {
        x = chartLeft + chartWidth / 2;
      } else {
        x = chartLeft + (chartWidth * i / (history.length - 1));
      }

      final double y = item.atRisk
          ? chartTop + chartHeight * 0.18
          : chartBottom - chartHeight * 0.18;

      points.add(Offset(x, y));
    }

    // ================================================================
    // GARIS GRAFIK
    // ================================================================

    if (points.length > 1) {
      for (int i = 0; i < points.length - 1; i++) {
        final Offset first = points[i];
        final Offset second = points[i + 1];

        final bool firstRisk = history[i].atRisk;

        final bool secondRisk = history[i + 1].atRisk;

        final Paint linePaint;

        if (firstRisk && secondRisk) {
          linePaint = riskLinePaint;
        } else if (!firstRisk && !secondRisk) {
          linePaint = safeLinePaint;
        } else {
          linePaint = secondRisk ? riskLinePaint : safeLinePaint;
        }

        canvas.drawLine(first, second, linePaint);
      }
    }

    // ================================================================
    // TITIK
    // ================================================================

    for (int i = 0; i < points.length; i++) {
      final bool atRisk = history[i].atRisk;

      final Paint pointPaint = Paint()
        ..color = atRisk ? const Color(0xFFE96B68) : const Color(0xFF61C58A);

      canvas.drawCircle(points[i], 4, pointPaint);

      final Paint innerPaint = Paint()..color = Colors.white;

      canvas.drawCircle(points[i], 1.5, innerPaint);
    }

    // ================================================================
    // LABEL Y
    // ================================================================

    _drawText(
      canvas,
      'Berisiko',
      Offset(5, chartTop + chartHeight * 0.10),
      const TextStyle(
        fontFamily: 'Nunito',
        fontSize: 10,
        color: Color(0xFFE96B68),
        fontWeight: FontWeight.w700,
      ),
    );

    _drawText(
      canvas,
      'GERD',
      Offset(18, chartTop + chartHeight * 0.10 + 10),
      const TextStyle(
        fontFamily: 'Nunito',
        fontSize: 10,
        color: Color(0xFFE96B68),
        fontWeight: FontWeight.w700,
      ),
    );

    _drawText(
      canvas,
      'Tidak',
      Offset(5, chartBottom - chartHeight * 0.19),
      const TextStyle(
        fontFamily: 'Nunito',
        fontSize: 10,
        color: Color(0xFF61C58A),
        fontWeight: FontWeight.w700,
      ),
    );

    _drawText(
      canvas,
      'berisiko',
      Offset(2, chartBottom - chartHeight * 0.19 + 10),
      const TextStyle(
        fontFamily: 'Nunito',
        fontSize: 10,
        color: Color(0xFF61C58A),
        fontWeight: FontWeight.w700,
      ),
    );

    _drawText(
      canvas,
      'GERD',
      Offset(18, chartBottom - chartHeight * 0.19 + 20),
      const TextStyle(
        fontFamily: 'Nunito',
        fontSize: 10,
        color: Color(0xFF61C58A),
        fontWeight: FontWeight.w700,
      ),
    );

    // ================================================================
    // LABEL X = TANGGAL
    // ================================================================

    for (int i = 0; i < history.length; i++) {
      final double x;

      if (history.length == 1) {
        x = chartLeft + chartWidth / 2;
      } else {
        x = chartLeft + (chartWidth * i / (history.length - 1));
      }

      final String dateText =
          '${history[i].date.day} ${_monthName(history[i].date.month)}';

      final String timeText =
          '${history[i].date.hour.toString().padLeft(2, '0')}:'
          '${history[i].date.minute.toString().padLeft(2, '0')}';

      _drawCenteredText(
        canvas,
        dateText,
        Offset(x, chartBottom + 5),
        const TextStyle(
          fontFamily: 'Nunito',
          fontSize: 6.5,
          fontWeight: FontWeight.w400,
          color: Color(0xFF65554F),
        ),
      );

      _drawCenteredText(
        canvas,
        timeText,
        Offset(x, chartBottom + 14),
        const TextStyle(
          fontFamily: 'Nunito',
          fontSize: 6,
          fontWeight: FontWeight.w400,
          color: Color(0xFF8B7B75),
        ),
      );

      _drawCenteredText(
        canvas,
        history[i].atRisk ? 'Berisiko' : 'Tidak',
        Offset(x, history[i].atRisk ? chartTop + 2 : chartBottom - 30),
        TextStyle(
          fontFamily: 'Nunito',
          fontSize: 6,
          fontWeight: FontWeight.w700,
          color: history[i].atRisk
              ? const Color(0xFFE96B68)
              : const Color(0xFF61C58A),
        ),
      );
    }
  }

  // ===================================================================
  // EMPTY STATE
  // ===================================================================

  void _drawEmptyState(Canvas canvas, Size size) {
    _drawCenteredText(
      canvas,
      'Belum ada riwayat skrining',
      Offset(size.width / 2, size.height / 2 - 6),
      const TextStyle(
        fontFamily: 'Nunito',
        fontSize: 11,
        color: Color(0xFF777777),
        fontWeight: FontWeight.w700,
      ),
    );

    _drawCenteredText(
      canvas,
      'Lakukan skrining untuk melihat grafik',
      Offset(size.width / 2, size.height / 2 + 12),
      const TextStyle(
        fontFamily: 'Nunito',
        fontSize: 8,
        color: Color(0xFF999999),
        fontWeight: FontWeight.w400,
      ),
    );
  }

  // ===================================================================
  // DRAW TEXT
  // ===================================================================

  void _drawText(Canvas canvas, String text, Offset offset, TextStyle style) {
    final TextPainter painter = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
    );

    painter.layout();

    painter.paint(canvas, offset);
  }

  // ===================================================================
  // DRAW CENTER TEXT
  // ===================================================================

  void _drawCenteredText(
    Canvas canvas,
    String text,
    Offset center,
    TextStyle style,
  ) {
    final TextPainter painter = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    );

    painter.layout();

    painter.paint(canvas, Offset(center.dx - painter.width / 2, center.dy));
  }

  // ===================================================================
  // MONTH
  // ===================================================================

  String _monthName(int month) {
    const List<String> months = [
      '',
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'Mei',
      'Jun',
      'Jul',
      'Agu',
      'Sep',
      'Okt',
      'Nov',
      'Des',
    ];

    return months[month];
  }

  @override
  bool shouldRepaint(covariant GERDChartPainter oldDelegate) {
    return oldDelegate.history != history;
  }
}
